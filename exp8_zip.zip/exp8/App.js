// import logo from './logo.svg';
import React from 'react' ;
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
// import {Component} from 'react';
import Counter from './components/Counter';
import About from './components/About';
import Users from './components/Users';
import Home from './components/Home';
import './App.css';

export default function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home />}/>
          <Route path="/about" element={<About />}/>
          <Route path="/user" element={<Users />}/>
          <Route path="/Counter" element={<Counter />}/>
        </Routes>
      </Router>
    </div>
  );
}