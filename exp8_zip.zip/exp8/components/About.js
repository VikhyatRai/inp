import React from 'react';
export default function About(){
    return (
        <div className='about'>
            <h1>This is the About Page</h1>
        </div>
    )
}