import React from "react";
export default function Users(){
    return (
        <div className="Users" >
            <h1>This is Users page</h1>
        </div>
    )
}