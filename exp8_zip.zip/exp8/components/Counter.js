import React from 'react';
export default function Counter(){
    return (
        <div className='Counter'>
            <h1>This is Counter Page</h1>
        </div>
    )
}