import React from "react"; 
function Function(){
    return(
    <div>
    <p><h1>This is function component.</h1></p><br></br>
    <ul>
    <li>A</li>
    <li>B</li>
    <li>C</li>
    </ul>
    </div>
    );
    }
    
    export default Function;