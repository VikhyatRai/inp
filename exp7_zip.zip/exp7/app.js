// exp -7   Installation of react & create a class & function component.
import './app.css';
import Function from './Function'; 
import Class1 from './class.js';
import Hook2useState from './Components/Hook2useState';

function App(){ 
    return(
<div className="App">
<>
<Function/>
<Class1/>
</>
<header className="App-header">
<h1>HariOm Shukla </h1>
<a
className="App-link" href="htpps://react.org" target="_blank" rel="noopener noreferrer"
>
Learn React
</a>
</header>
</div>
);
}
export default App;