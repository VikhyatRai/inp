import React, { Component } from "react"; 
class Class1 extends Component{
    WebGL2RenderingContext(){ return(
    <div>
    <p><h1>This is class Component</h1></p><br></br>
    <ul>
    <li>X</li>
    <li>Y</li>
    <li>Z</li>
    </ul>
    </div>
    );
    }
    }
    
    export default Class1;