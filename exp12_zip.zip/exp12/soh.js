// exp-12   Install Express JS Framework and write a program to take first name and last name using get method and to display “Hello World”.
var express = require('express');
var app = express();

app.use(express.static('public'));

app.get('/som.html', function (req, res) {
    res.sendFile(__dirname + "/" +"som.html");
});

app.get('/process_get', function (req, res) {
    var response = {
        first_name: req.query.first_name,
        last_name: req.query.last_name
    };

    console.log(response);
    res.json(response); // Use res.json() to send a JSON response
});

var server = app.listen(9000, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
});


  


// const express = require('express'); 
// const app = express();
// const port = 3000; 
//  app.get('/', (req, res) => {
// res.send('Hello, World!');

// });

// app.listen(port, () => {

// console.log("Server is running at http://localhost:${port}");

// })